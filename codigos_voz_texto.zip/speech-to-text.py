# --- START OF FILE speech-to-text.py ---


import queue
import re
import sys
import time
import threading # Added for keyboard input

from google.cloud import speech
import pyaudio

# Parámetros de grabación de audio
STREAMING_LIMIT = 240000  # 4 minutes
SAMPLE_RATE = 16000
CHUNK_SIZE = int(SAMPLE_RATE / 10)  # 100ms

RED = "\033[0;31m"
GREEN = "\033[0;32m"
YELLOW = "\033[0;33m"
RESET_COLOR = "\033[0m" # Added to reset color

def get_current_time() -> int:
    """Return Current Time in MS.

    Returns:
        int: Current Time in MS.
    """

    return int(round(time.time() * 1000))


class ResumableMicrophoneStream:
    """Opens a recording stream as a generator yielding the audio chunks."""

    def __init__(
        self: object,
        rate: int,
        chunk_size: int,
    ) -> None:
        """Creates a resumable microphone stream.

        Args:
        self: The class instance.
        rate: The audio file's sampling rate.
        chunk_size: The audio file's chunk size.

        returns: None
        """
        self._rate = rate
        self.chunk_size = chunk_size
        self._num_channels = 1
        self._buff = queue.Queue()
        self.closed = True
        self.start_time = get_current_time()
        self.restart_counter = 0
        self.audio_input = []
        self.last_audio_input = []
        self.result_end_time = 0
        self.is_final_end_time = 0
        self.final_request_end_time = 0
        self.bridging_offset = 0
        self.last_transcript_was_final = False
        self.new_stream = True
        self._audio_interface = pyaudio.PyAudio()
        self._audio_stream = self._audio_interface.open(
            format=pyaudio.paInt16,
            channels=self._num_channels,
            rate=self._rate,
            input=True,
            frames_per_buffer=self.chunk_size,
            stream_callback=self._fill_buffer,
        )

    def __enter__(self: object) -> object:
        """Opens the stream.

        Args:
        self: The class instance.

        returns: None
        """
        self.closed = False
        return self

    def __exit__(
        self: object,
        type: object,
        value: object,
        traceback: object,
    ) -> object:
        """Closes the stream and releases resources.

        Args:
        self: The class instance.
        type: The exception type.
        value: The exception value.
        traceback: The exception traceback.

        returns: None
        """
        self.closed = True # Ensure closed is set if exiting due to an exception
        if self._audio_stream and self._audio_stream.is_active():
            self._audio_stream.stop_stream()
            self._audio_stream.close()
        
        # Indica al generador que termine para 
        # que el método streaming_recognize del cliente 
        # no bloquee la finalización del proceso.
        self._buff.put(None)
        if self._audio_interface:
            self._audio_interface.terminate()

    def _fill_buffer(
        self: object,
        in_data: object,
        *args: object,
        **kwargs: object,
    ) -> object:
        """Continuously collect data from the audio stream, into the buffer.

        Args:
        self: The class instance.
        in_data: The audio data as a bytes object.
        args: Additional arguments.
        kwargs: Additional arguments.

        returns: None
        """
        self._buff.put(in_data)
        return None, pyaudio.paContinue

    def generator(self: object) -> object:
        """Stream Audio from microphone to API and to local buffer

        Args:
            self: The class instance.

        returns:
            The data from the audio stream.
        """
        while not self.closed:
            data = []

            if self.new_stream and self.last_audio_input:
                chunk_time = STREAMING_LIMIT / len(self.last_audio_input)

                if chunk_time != 0:
                    if self.bridging_offset < 0:
                        self.bridging_offset = 0

                    if self.bridging_offset > self.final_request_end_time:
                        self.bridging_offset = self.final_request_end_time

                    chunks_from_ms = round(
                        (self.final_request_end_time - self.bridging_offset)
                        / chunk_time
                    )

                    self.bridging_offset = round(
                        (len(self.last_audio_input) - chunks_from_ms) * chunk_time
                    )

                    for i in range(chunks_from_ms, len(self.last_audio_input)):
                        data.append(self.last_audio_input[i])

                self.new_stream = False


            # Usa un get() bloqueante para asegurarte de que haya al menos un fragmento de datos,
            # y detén la iteración si el fragmento es None, lo que indica el final del flujo de audio.
            try:
                # Use a timeout to allow checking self.closed periodically
                chunk = self._buff.get(block=True, timeout=0.1)
            except queue.Empty:
                if self.closed:
                    return
                continue # Go back to the start of the while loop if queue is empty but not closed

            self.audio_input.append(chunk)

            if chunk is None: # This will be put by __exit__
                return
            data.append(chunk)
            # Ahora se consume cualquier otro dato que aún esté en el búfer.
            while True:
                try:
                    chunk = self._buff.get(block=False)

                    if chunk is None: # This will be put by __exit__
                        return
                    data.append(chunk)
                    self.audio_input.append(chunk)

                except queue.Empty:
                    break
            
            if data: # Only yield if there's data
                yield b"".join(data)


def listen_print_loop(responses: object, stream: object) -> None:
    """Iterates through server responses and prints them.

    The responses passed is a generator that will block until a response
    is provided by the server.

    Each response may contain multiple results, and each result may contain
    multiple alternatives; for details, see https://goo.gl/tjCPAU.  Here we
    print only the transcription for the top alternative of the top result.

    In this case, responses are provided for interim results as well. If the
    response is an interim one, print a line feed at the end of it, to allow
    the next result to overwrite it, until the response is a final one. For the
    final one, print a newline to preserve the finalized transcription.

    Arg:
        responses: The responses returned from the API.
        stream: The audio stream to be processed.
    """
    with open("transcriptions.txt", "a", encoding="utf-8") as file:
        try:
            for response in responses:
                if stream.closed: # Check if Enter was pressed or stream closed by other means
                    break

                if get_current_time() - stream.start_time > STREAMING_LIMIT:
                    stream.start_time = get_current_time()
                    break

                if not response.results:
                    continue

                result = response.results[0]

                if not result.alternatives:
                    continue

                transcript = result.alternatives[0].transcript

                result_seconds = 0
                result_micros = 0

                if result.result_end_time.seconds:
                    result_seconds = result.result_end_time.seconds

                if result.result_end_time.microseconds: # microseconds, not micro_seconds
                    result_micros = result.result_end_time.microseconds

                stream.result_end_time = int((result_seconds * 1000) + (result_micros / 1000))

                corrected_time = (
                    stream.result_end_time
                    - stream.bridging_offset
                    + (STREAMING_LIMIT * stream.restart_counter)
                )
                
                if result.is_final:
                    sys.stdout.write(GREEN)
                    sys.stdout.write("\033[K")
                    sys.stdout.write(str(corrected_time) + ": " + transcript + "\n")
                    sys.stdout.write(RESET_COLOR) # Reset color

                    file.write(f"{corrected_time}: {transcript}\n")
                    file.flush() # Ensure it's written immediately

                    stream.is_final_end_time = stream.result_end_time
                    stream.last_transcript_was_final = True

                    if re.search(r"\b(salir|quitar)\b", transcript, re.I):
                        sys.stdout.write(YELLOW)
                        sys.stdout.write("Exiting due to voice command...\n")
                        sys.stdout.write(RESET_COLOR) # Reset color
                        stream.closed = True
                        break
                else:
                    sys.stdout.write(RED)
                    sys.stdout.write("\033[K")
                    sys.stdout.write(str(corrected_time) + ": " + transcript + "\r")
                    sys.stdout.write(RESET_COLOR) # Reset color

                    stream.last_transcript_was_final = False
        except Exception as e:
            # This can happen if the stream is closed while waiting for response
            if not stream.closed: # Only print if not intentionally closed
                print(f"{RED}Error in listen_print_loop: {e}{RESET_COLOR}")
            pass # Suppress errors if stream is closed
        finally:
            # Ensure the cursor is on a new line and color is reset if loop breaks early
            sys.stdout.write("\033[K") # Clear current line
            sys.stdout.write(RESET_COLOR + "\n")


def listen_for_enter_key(stream_obj: ResumableMicrophoneStream):
    """
    Waits for the user to press Enter and then sets the stream's closed flag.
    This function is intended to be run in a separate thread.
    """
    try:
        input() # This will block until Enter is pressed
        if not stream_obj.closed:
            print(f"\n{YELLOW}Enter key pressed, stopping transcription...{RESET_COLOR}")
            stream_obj.closed = True
    except EOFError:
        # This can happen if stdin is closed, e.g. when run in some environments
        # or if the main thread exits abruptly.
        if not stream_obj.closed:
            print(f"\n{YELLOW}Input stream closed, stopping transcription...{RESET_COLOR}")
            stream_obj.closed = True
    except Exception as e:
        if not stream_obj.closed: # Only print if not intentionally closed
            print(f"{RED}Error in keyboard listener: {e}{RESET_COLOR}")
            stream_obj.closed = True


def main() -> None:
    """Se inicia la transmisión bidireccional desde la entrada del micrófono hacia la API de reconocimiento de voz."""
    client = speech.SpeechClient()
    config = speech.RecognitionConfig(
        encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=SAMPLE_RATE,
        language_code="es-CL",
        max_alternatives=1,
        enable_automatic_punctuation=True, # Added for better transcriptions
    )

    streaming_config = speech.StreamingRecognitionConfig(
        config=config, interim_results=True
    )

    mic_manager = ResumableMicrophoneStream(SAMPLE_RATE, CHUNK_SIZE)
    
    sys.stdout.write(YELLOW)
    sys.stdout.write(f'\nEscuchando, di "salir" o "quitar" para detener, o presiona Enter.\n\n')
    sys.stdout.write("End (ms)       Resultados de la transcripcion/Status\n")
    sys.stdout.write("=====================================================\n")
    sys.stdout.write(RESET_COLOR) # Reset color

    # Start the keyboard listener thread
    # It's a daemon thread so it will exit when the main program exits
    keyboard_thread = threading.Thread(target=listen_for_enter_key, args=(mic_manager,), daemon=True)
    keyboard_thread.start()

    with mic_manager as stream:
        try:
            while not stream.closed:
                if not keyboard_thread.is_alive() and not stream.closed :
                    # If the keyboard thread died for some reason, and we are not already closing
                    print(f"{RED}Keyboard listener thread has stopped. Exiting.{RESET_COLOR}")
                    stream.closed = True
                    break

                sys.stdout.write(YELLOW)
                sys.stdout.write(
                    "\n" + str(STREAMING_LIMIT * stream.restart_counter) + ": NEW REQUEST\n"
                )
                sys.stdout.write(RESET_COLOR) # Reset color

                stream.audio_input = []
                audio_generator = stream.generator()

                requests = (
                    speech.StreamingRecognizeRequest(audio_content=content)
                    for content in audio_generator
                )
                
                try:
                    responses = client.streaming_recognize(streaming_config, requests)
                    listen_print_loop(responses, stream)
                except Exception as e:
                    if stream.closed: # If already closing (e.g. by Enter key), this is expected
                        break
                    print(f"{RED}Error during streaming_recognize or listen_print_loop: {e}{RESET_COLOR}")
                    # Potentially add a retry mechanism or a delay here if desired
                    # For now, we'll just let it try to restart the stream
                    # stream.closed = True # Uncomment to exit on this type of error
                    # break

                if stream.closed: # Check again if Enter or voice command closed it
                    break

                if stream.result_end_time > 0:
                    stream.final_request_end_time = stream.is_final_end_time
                stream.result_end_time = 0
                stream.last_audio_input = []
                stream.last_audio_input = stream.audio_input
                stream.audio_input = []
                stream.restart_counter = stream.restart_counter + 1

                if not stream.last_transcript_was_final:
                    sys.stdout.write("\n") # Ensure a newline if the last result wasn't final
                stream.new_stream = True
        
        except KeyboardInterrupt:
            print(f"\n{YELLOW}Interrupción por teclado (Ctrl+C) detectada. Saliendo...{RESET_COLOR}")
            stream.closed = True # Ensure stream is marked as closed
        finally:
            if not stream.closed: # Ensure stream is closed if loop exited abnormally
                 stream.closed = True
            # The 'with' statement will call __exit__ which handles cleanup.
            # We just ensure the keyboard thread is notified if it's still somehow running
            # (though as a daemon it should terminate with main)
            print(f"{YELLOW}Proceso de transcripción finalizado.{RESET_COLOR}")


if __name__ == "__main__":
    main()
# --- END OF FILE speech-to-text.py ---
