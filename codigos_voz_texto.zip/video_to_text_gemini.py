import queue
import re
import sys
import time
import os
import subprocess # Para ejecutar ffmpeg

# Para Gemini
import google.generativeai as genai
from google.generativeai.types import GenerationConfig # Para configurar la temperatura
from dotenv import load_dotenv

# Para preprocesamiento de audio
import soundfile as sf
import numpy as np
import noisereduce as nr

# --- Parámetros de Configuración y Diagnóstico ---
SAMPLE_RATE = 16000

# --- Parámetros de Preprocesamiento de Audio ---
NORMALIZE_AUDIO = True
TARGET_DBFS = -20.0

APPLY_NOISE_REDUCTION = False # Desactivado según tu última prueba, puedes cambiarlo
NOISE_PROFILE_PATH = None
NOISE_PROFILE_FALLBACK_DURATION_SEC = 2.0
PROP_DECREASE_INITIAL = 0.4
N_STD_THRESH_STATIONARY_INITIAL = 2.2
NR_N_FFT = 2048
NR_HOP_LENGTH = NR_N_FFT // 4
NR_TIME_MASK_SMOOTH_MS = 150

# --- Parámetros de Gemini ---
GEMINI_MODEL_NAME = 'gemini-1.5-flash-latest' # O 'gemini-1.5-pro-latest'
GEMINI_TEMPERATURE = 0.1 # Rango típico para transcripción: 0.0 a 0.3. Más bajo es más determinista.

# --- Colores para la Consola ---
RED = "\033[0;31m"
GREEN = "\033[0;32m"
YELLOW = "\033[0;33m"
CYAN = "\033[0;36m"
RESET_COLOR = "\033[0m"

# --- [INICIO] SECCIÓN MODIFICADA: CONFIGURACIÓN DE LA API DE GEMINI ---

# Cargar variables de entorno (esto permite usar un archivo .env si existe)
load_dotenv()

# Intenta obtener la clave del entorno. Si no la encuentra, usa la que está escrita aquí.
# ADVERTENCIA DE SEGURIDAD: No compartas este archivo si pones tu clave directamente en el código.
API_KEY_HARDCODED = "Obtener api desde gemini"

api_key = os.environ.get("GEMINI_API_KEY") or API_KEY_HARDCODED

if not api_key or api_key == "REEMPLAZA_CON_TU_API_KEY_AQUI":
    print(f"{RED}Error Crítico: La clave de API de Gemini no está configurada.{RESET_COLOR}")
    print(f"{YELLOW}Por favor, edita el script y reemplaza 'REEMPLAZA_CON_TU_API_KEY_AQUI' con tu clave real.{RESET_COLOR}")
    sys.exit(1) # Salir del script si la clave no está configurada

try:
    genai.configure(api_key=api_key)
    print(f"{GREEN}API de Gemini configurada correctamente.{RESET_COLOR}")
except Exception as e:
    print(f"{RED}Error al configurar la API de Gemini: {e}{RESET_COLOR}")
    sys.exit(1)

# --- [FIN] SECCIÓN MODIFICADA ---


# --- Funciones de Preprocesamiento de Audio (sin cambios) ---

def extract_audio_with_ffmpeg(video_file_path: str, output_audio_file_path: str, sample_rate: int) -> bool:
    print(f"{CYAN}Extrayendo audio de '{video_file_path}' usando ffmpeg CLI...{RESET_COLOR}")
    command = [
        "ffmpeg", "-i", video_file_path,
        "-vn", "-ac", "1", "-ar", str(sample_rate),
        "-acodec", "pcm_s16le", "-y", output_audio_file_path,
    ]
    try:
        process = subprocess.run(command, capture_output=True, text=True, check=True, encoding='utf-8', errors='replace')
        if process.stderr and "ffmpeg version" not in process.stderr.lower():
             print(f"{CYAN}ffmpeg stderr (info/warnings):\n{process.stderr}{RESET_COLOR}")
        print(f"{GREEN}Audio extraído a '{output_audio_file_path}' usando ffmpeg CLI.{RESET_COLOR}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"{RED}Error FATAL durante la ejecución de ffmpeg:{RESET_COLOR}")
        print(f"{RED}Comando: {' '.join(e.cmd)}{RESET_COLOR}")
        print(f"{RED}Código de retorno: {e.returncode}{RESET_COLOR}")
        stderr_output = e.stderr
        if isinstance(stderr_output, bytes): stderr_output = stderr_output.decode('utf-8', errors='replace')
        print(f"{RED}Error (stderr):\n{stderr_output}{RESET_COLOR}")
        return False
    except FileNotFoundError:
        print(f"{RED}Error FATAL: El comando 'ffmpeg' no se encontró.{RESET_COLOR}")
        return False
    except Exception as e:
        print(f"{RED}Error inesperado al ejecutar ffmpeg: {e}{RESET_COLOR}")
        return False

def normalize_audio_ffmpeg_cli(input_path: str, output_path: str, target_dbfs: float, sample_rate: int) -> bool:
    print(f"{CYAN}Normalizando audio '{os.path.basename(input_path)}' a {target_dbfs} dBFS usando ffmpeg CLI...{RESET_COLOR}")
    detect_command = ["ffmpeg", "-i", input_path, "-af", "volumedetect", "-f", "null", "-"]
    max_volume_db = None
    try:
        process_detect = subprocess.run(detect_command, capture_output=True, text=True, check=False, encoding='utf-8', errors='replace')
        for line in process_detect.stderr.splitlines():
            if "max_volume" in line:
                match = re.search(r"max_volume:\s*(-?\d+\.?\d*)\s*dB", line)
                if match:
                    max_volume_db = float(match.group(1))
                    print(f"{CYAN}Pico máximo detectado: {max_volume_db} dB{RESET_COLOR}")
                    break
        if max_volume_db is None:
            print(f"{RED}No se pudo extraer max_volume de la salida de ffmpeg.{RESET_COLOR}")
            return False
    except Exception as e:
        print(f"{RED}Error inesperado durante la detección de volumen con ffmpeg: {e}{RESET_COLOR}")
        return False

    gain_db = target_dbfs - max_volume_db
    print(f"{CYAN}Ganancia a aplicar: {gain_db:.2f} dB{RESET_COLOR}")
    normalize_command = [
        "ffmpeg", "-i", input_path, "-af", f"volume={gain_db:.2f}dB",
        "-ar", str(sample_rate), "-ac", "1", "-acodec", "pcm_s16le", "-y", output_path
    ]
    try:
        process_normalize = subprocess.run(normalize_command, capture_output=True, text=True, check=True, encoding='utf-8', errors='replace')
        if process_normalize.stderr and "ffmpeg version" not in process_normalize.stderr.lower():
             print(f"{CYAN}ffmpeg normalize stderr (info/warnings):\n{process_normalize.stderr}{RESET_COLOR}")
        print(f"{GREEN}Audio normalizado con ffmpeg CLI guardado en '{output_path}'.{RESET_COLOR}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"{RED}Error FATAL durante la normalización con ffmpeg (pasada 2):{RESET_COLOR}")
        print(f"{RED}Comando: {' '.join(e.cmd)}{RESET_COLOR}")
        stderr_output = e.stderr
        if isinstance(stderr_output, bytes): stderr_output = stderr_output.decode('utf-8', errors='replace')
        print(f"{RED}Error (stderr):\n{stderr_output}{RESET_COLOR}")
        return False
    except Exception as e:
        print(f"{RED}Error inesperado al aplicar ganancia con ffmpeg: {e}{RESET_COLOR}")
        return False

def apply_noise_reduction_nr(input_path: str, output_path: str, sample_rate: int) -> bool:
    print(f"{CYAN}Aplicando reducción de ruido a '{os.path.basename(input_path)}'...{RESET_COLOR}")
    noise_profile_data_to_use = None
    try:
        if NOISE_PROFILE_PATH and os.path.exists(NOISE_PROFILE_PATH):
            print(f"{CYAN}Cargando perfil de ruido desde: {NOISE_PROFILE_PATH}{RESET_COLOR}")
            noise_audio_segment, noise_rate = sf.read(NOISE_PROFILE_PATH, dtype='float32')
            if noise_rate != sample_rate:
                print(f"{RED}Error: Tasa de muestreo del perfil de ruido ({noise_rate}Hz) no coincide ({sample_rate}Hz). Usando fallback.{RESET_COLOR}")
            else:
                noise_profile_data_to_use = noise_audio_segment
        
        if noise_profile_data_to_use is None:
            print(f"{YELLOW}Usando los primeros {NOISE_PROFILE_FALLBACK_DURATION_SEC}s de '{os.path.basename(input_path)}' para perfil de ruido (fallback).{RESET_COLOR}")
            temp_audio_data, temp_rate = sf.read(input_path, dtype='float32')
            if temp_rate == sample_rate:
                noise_clip_samples = int(min(NOISE_PROFILE_FALLBACK_DURATION_SEC * temp_rate, len(temp_audio_data)))
                if noise_clip_samples > 0:
                    noise_profile_data_to_use = temp_audio_data[0:noise_clip_samples]
                else:
                    print(f"{RED}Audio demasiado corto para perfil de ruido de fallback.{RESET_COLOR}")
                    return False 
            else:
                print(f"{RED}Discrepancia de tasa de muestreo al leer audio para fallback.{RESET_COLOR}")
                return False

        if noise_profile_data_to_use is not None:
            main_audio_data, main_audio_rate = sf.read(input_path, dtype='float32')
            if main_audio_rate == sample_rate:
                reduced_noise_audio = nr.reduce_noise(
                    y=main_audio_data, sr=main_audio_rate, y_noise=noise_profile_data_to_use,
                    prop_decrease=PROP_DECREASE_INITIAL, n_std_thresh_stationary=N_STD_THRESH_STATIONARY_INITIAL,
                    n_fft=NR_N_FFT, hop_length=NR_HOP_LENGTH, time_mask_smooth_ms=NR_TIME_MASK_SMOOTH_MS
                )
                if reduced_noise_audio.dtype != np.float32:
                    reduced_noise_audio = reduced_noise_audio.astype(np.float32)
                sf.write(output_path, reduced_noise_audio, main_audio_rate, subtype='PCM_16')
                print(f"{GREEN}Audio con ruido reducido guardado en '{output_path}'{RESET_COLOR}")
                return True
            else:
                print(f"{RED}Discrepancia de tasa de muestreo al leer audio para reducción de ruido.{RESET_COLOR}")
        else:
            print(f"{YELLOW}No se pudo obtener un perfil de ruido. Saltando reducción de ruido.{RESET_COLOR}")

    except Exception as e_nr:
        print(f"{RED}Error durante la reducción de ruido: {e_nr}{RESET_COLOR}")
    return False

# --- Funciones de Transcripción con Gemini ---

def limpiar_timestamps_gemini(texto_con_timestamps: str) -> str:
    texto_limpio = re.sub(r"^\s*\[\d{2}:\d{2}:\d{2}(\.\d+)?\]\s*", "", texto_con_timestamps, flags=re.MULTILINE)
    return texto_limpio.strip()

def transcribe_with_gemini(audio_file_path: str, output_txt_path: str) -> bool:
    print(f"{CYAN}Iniciando transcripción con Gemini para: {os.path.basename(audio_file_path)}{RESET_COLOR}")
    try:
        # La configuración de la API ya se hizo al inicio del script, no es necesario repetirla aquí.
        
        print(f"{CYAN}Usando el modelo Gemini: {GEMINI_MODEL_NAME} con Temperatura: {GEMINI_TEMPERATURE}{RESET_COLOR}")
        model = genai.GenerativeModel(GEMINI_MODEL_NAME)

        print(f"{CYAN}Subiendo archivo de audio a Gemini: {os.path.basename(audio_file_path)}...{RESET_COLOR}")
        audio_file_for_api = genai.upload_file(path=audio_file_path)
        print(f"{GREEN}Archivo subido: {audio_file_for_api.name}, Estado inicial: {audio_file_for_api.state.name}{RESET_COLOR}")

        print(f"{YELLOW}Esperando a que el archivo esté activo...{RESET_COLOR}", end="")
        intentos_espera = 0
        max_intentos_espera = 45 
        
        while audio_file_for_api.state.name == "PROCESSING":
            intentos_espera += 1
            if intentos_espera > max_intentos_espera:
                print(f"\n{RED}Tiempo de espera agotado. El archivo sigue procesándose.{RESET_COLOR}")
                try: genai.delete_file(name=audio_file_for_api.name)
                except Exception: pass
                return False
            print(f"{YELLOW}.{RESET_COLOR}", end="", flush=True)
            time.sleep(2)
            try: audio_file_for_api = genai.get_file(name=audio_file_for_api.name)
            except Exception as e_get:
                print(f"\n{RED}Error al obtener estado del archivo: {e_get}{RESET_COLOR}"); return False
        
        print(f"\n{CYAN}Estado final del archivo: {audio_file_for_api.state.name}{RESET_COLOR}")

        if audio_file_for_api.state.name != "ACTIVE":
            print(f"{RED}El archivo no está activo (estado: {audio_file_for_api.state.name}). Falló: {getattr(audio_file_for_api, 'error', 'N/A')}{RESET_COLOR}")
            try: genai.delete_file(name=audio_file_for_api.name)
            except Exception: pass
            return False

        prompt = ("Por favor, transcribe el audio proporcionado con la mayor precisión posible. "
                  "Devuelve solo el texto de la transcripción, sin incluir timestamps ni otra información de formato adicional.")
        
        print(f"{CYAN}Generando transcripción con Gemini...{RESET_COLOR}")
        
        generation_config_gemini = GenerationConfig(
            temperature=GEMINI_TEMPERATURE
        )
        
        response = None
        try:
            response = model.generate_content(
                [prompt, audio_file_for_api],
                generation_config=generation_config_gemini
            )
        except Exception as e_gen:
            print(f"{RED}Error durante generate_content: {e_gen}{RESET_COLOR}")
        
        try:
            print(f"{CYAN}Intentando eliminar archivo de Gemini: {audio_file_for_api.name}{RESET_COLOR}")
            genai.delete_file(name=audio_file_for_api.name)
            print(f"{GREEN}Archivo de Gemini '{audio_file_for_api.name}' eliminado.{RESET_COLOR}")
        except Exception as e_del:
            print(f"{YELLOW}Advertencia: No se pudo eliminar el archivo de Gemini '{audio_file_for_api.name}': {e_del}{RESET_COLOR}")

        if response and response.candidates and response.candidates[0].content.parts:
            transcribed_text_raw = response.text
            transcribed_text_cleaned = limpiar_timestamps_gemini(transcribed_text_raw)
            try:
                with open(output_txt_path, "w", encoding="utf-8") as f:
                    f.write(transcribed_text_cleaned)
                print(f"\n{GREEN}Transcripción de Gemini guardada en: {output_txt_path}{RESET_COLOR}")
                return True
            except IOError as e_io:
                print(f"{RED}Error al guardar la transcripción: {e_io}{RESET_COLOR}")
        else:
            print(f"\n{RED}No se recibió una transcripción válida de Gemini.{RESET_COLOR}")
            if response: print(f"{YELLOW}Respuesta (para depuración):{RESET_COLOR}", response)
        return False

    except Exception as e:
        print(f"{RED}Ocurrió un error general en transcribe_with_gemini: {e}{RESET_COLOR}")
    return False

# --- Función Principal ---
def main():
    # La verificación de la API KEY ya se hace al inicio del script.
    
    video_path = input(f"{CYAN}Por favor, introduce la ruta al archivo de video: {RESET_COLOR}")
    if not os.path.exists(video_path):
        print(f"{RED}El archivo de video '{video_path}' no existe.{RESET_COLOR}")
        return

    base_name = os.path.splitext(os.path.basename(video_path))[0]
    temp_dir = os.path.dirname(os.path.abspath(video_path))
    os.makedirs(temp_dir, exist_ok=True)

    temp_audio_path_extracted = os.path.join(temp_dir, f"{base_name}_temp_extracted.wav")
    temp_audio_path_normalized = os.path.join(temp_dir, f"{base_name}_temp_normalized.wav")
    temp_audio_path_denoised = os.path.join(temp_dir, f"{base_name}_temp_denoised.wav")
    
    output_transcription_path_base = os.path.join(temp_dir, f"{base_name}_gemini_transcription")
    counter = 1
    output_transcription_path = f"{output_transcription_path_base}.txt"
    while os.path.exists(output_transcription_path):
        output_transcription_path = f"{output_transcription_path_base}_{counter}.txt"
        counter += 1
    if counter > 1:
        print(f"{YELLOW}Archivo de transcripción renombrado a: {os.path.basename(output_transcription_path)}{RESET_COLOR}")

    files_to_clean = []

    try:
        print(f"{CYAN}--- Inicio del Proceso de Transcripción (Video a Gemini) ---{RESET_COLOR}")

        if not extract_audio_with_ffmpeg(video_path, temp_audio_path_extracted, SAMPLE_RATE):
            print(f"{RED}Fallo en la extracción de audio. Abortando.{RESET_COLOR}")
            return
        files_to_clean.append(temp_audio_path_extracted)
        current_audio_path = temp_audio_path_extracted

        if NORMALIZE_AUDIO:
            if normalize_audio_ffmpeg_cli(current_audio_path, temp_audio_path_normalized, TARGET_DBFS, SAMPLE_RATE):
                current_audio_path = temp_audio_path_normalized
                files_to_clean.append(temp_audio_path_normalized)
            else:
                print(f"{YELLOW}Normalización falló. Usando audio anterior: '{os.path.basename(current_audio_path)}'.{RESET_COLOR}")
        else:
            print(f"{YELLOW}Normalización de audio desactivada.{RESET_COLOR}")

        if APPLY_NOISE_REDUCTION:
            if apply_noise_reduction_nr(current_audio_path, temp_audio_path_denoised, SAMPLE_RATE):
                current_audio_path = temp_audio_path_denoised
                files_to_clean.append(temp_audio_path_denoised)
            else:
                print(f"{YELLOW}Reducción de ruido falló. Usando audio anterior: '{os.path.basename(current_audio_path)}'.{RESET_COLOR}")
        else:
            print(f"{YELLOW}Reducción de ruido desactivada.{RESET_COLOR}")
        
        audio_to_transcribe_path = current_audio_path
        print(f"{CYAN}Audio final para transcripción con Gemini: {os.path.basename(audio_to_transcribe_path)}{RESET_COLOR}")

        if not transcribe_with_gemini(audio_to_transcribe_path, output_transcription_path):
            print(f"{RED}Fallo en la transcripción con Gemini.{RESET_COLOR}")
            return

        print(f"\n{GREEN}--- Proceso Completado ---{RESET_COLOR}")

    except Exception as e:
        print(f"{RED}Ocurrió un error general en main: {e}{RESET_COLOR}")
    finally:
        unique_files_to_clean = list(set(f for f in files_to_clean if f and os.path.exists(f)))
        if unique_files_to_clean:
            print(f"\n{CYAN}Limpiando archivos temporales...{RESET_COLOR}")
            for temp_file in unique_files_to_clean:
                print(f"{YELLOW}Eliminando: {os.path.basename(temp_file)}{RESET_COLOR}")
                try: os.remove(temp_file)
                except Exception as e_rm: print(f"{RED}Error al eliminar '{os.path.basename(temp_file)}': {e_rm}{RESET_COLOR}")
        print(f"{CYAN}--- Fin del Proceso ---{RESET_COLOR}")

if __name__ == "__main__":
    main()